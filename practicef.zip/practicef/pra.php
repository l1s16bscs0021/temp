<?php
$n=$_POST['na'];
echo "My name is:".$n;
echo "<br>";
$E=$_POST['em'];
echo "email is:".$E;

?>